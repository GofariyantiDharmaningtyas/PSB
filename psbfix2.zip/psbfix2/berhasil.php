<?php
    include 'koneksi.php';
    session_start();
    include 'koneksi.php';
    $peserta = mysqli_query($conn, "SELECT * FROM tb_pendaftaran 
    WHERE id_pendaftaran = '".$_GET['id']."' ");
    $p = mysqli_fetch_object($peserta);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300&display=swap" rel="stylesheet">
    <title>PSB</title>
</head>
<body>

    <!----bagian box form---->
    <section class="box-formulir">

        <h2>Pendaftaran Berhasil</h2><p style="text-align:right;"><a href= "keluar.php">Keluar</a></p>


        <div class="box">
        <h4>Kode Pendaftaran anda adalah <?php echo $_GET['id']?> </h4>
        <table class="table-data" border="0">
        <tr>
            <td>Tahun Ajaran</td>
            <td>:</td>
            <td><?php echo $p->th_ajaran ?></td>
        </tr>
        <tr>
            <td>Jurusan</td>
            <td>:</td>
            <td><?php echo $p->jurusan ?></td>
        </tr>
        <tr>
            <td>Nama Lengkap</td>
            <td>:</td>
            <td><?php echo $p->nm_peserta ?></td>
        </tr>
        <tr>
            <td>Tempat, Tanggal Lahir</td>
            <td>:</td>
            <td><?php echo $p->tmp_lahir.', '.$p->tgl_lahir ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin </td>
            <td>:</td>
            <td><?php echo $p->jk ?></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><?php echo $p->agama ?></td>
        </tr>
        <tr>
            <td>Alamat </td>
            <td>:</td>
            <td><?php echo $p->alamat ?></td>
        </tr>
        </table>
        </div>
        <div class="box">
        <h4>Nilai</h4>
        <table class="table-data" border="0">
        <tr>
            <td>Matematika</td>
                        <td>:</td>
                        <td><?php echo $p->mtk ?></td>
                    </tr>
                    <tr>
                        <td>Bahasa Inggris</td>
                        <td>:</td>
                        <td><?php echo $p->bing ?></td>
                    </tr>
                    <tr>
                        <td>Bahasa Indonesia</td>
                        <td>:</td>
                        <td><?php echo $p->bind ?></td>
                    </tr>
    </table>
    </div>
    <a href= "cetak-bukti.php?id=<?php echo $_GET['id']?> " target="_blank" class="btn-cetak">Cetak Bukti Daftar </a>

        

    </section>

</body>
</html>